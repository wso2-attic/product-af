var resources = function (page, meta) {
    return {
        js: ['editIssueBody.js']
    };
};