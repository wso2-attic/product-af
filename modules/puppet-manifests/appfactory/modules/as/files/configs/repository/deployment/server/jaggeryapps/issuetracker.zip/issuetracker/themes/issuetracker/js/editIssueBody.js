
$(document).ready(function() {
    $("#type").select2();
    $("#priority").select2();
    $("#issue_status").select2();
    $("#severity").select2();
    $("#projectKey").select2();
    $("#assignee").select2();
    $("#version").select2();
});