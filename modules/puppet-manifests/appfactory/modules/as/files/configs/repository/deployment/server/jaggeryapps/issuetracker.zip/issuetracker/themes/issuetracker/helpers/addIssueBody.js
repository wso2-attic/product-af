var resources = function (page, meta) {
    return {
        js: ['addIssueBody.js']
    };
};