//var cache = false;

var engine = caramel.engine('handlebars', (function () {
    return {
        //render:function(data){print(data)}
    };
}()));
